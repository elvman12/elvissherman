jQuery(".pp_accordion_close").accordion({ active: 1, collapsible: true, clearStyle: true });
jQuery(".pp_accordion").accordion({ active: 0, collapsible: true, clearStyle: true });