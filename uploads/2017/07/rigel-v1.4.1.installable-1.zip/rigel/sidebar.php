<?php
/**
 * The Sidebar containing the widget areas.
 *
 * @package WordPress
 */
?>

<ul class="sidebar_widget">
	<?php dynamic_sidebar( 'Page Sidebar' ); ?>
</ul>